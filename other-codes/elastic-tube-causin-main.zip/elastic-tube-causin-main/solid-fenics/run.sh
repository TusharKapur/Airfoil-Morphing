#!/bin/sh
set -e -u

python3 solid.py
