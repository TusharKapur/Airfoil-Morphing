#!/bin/sh
set -e -u

ccx_preCICE -i flap -precice-participant Solid
