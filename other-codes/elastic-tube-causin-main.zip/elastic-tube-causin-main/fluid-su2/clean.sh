#!/bin/sh
set -e -u

. ../../tools/cleaning-tools.sh

clean_su2 .
